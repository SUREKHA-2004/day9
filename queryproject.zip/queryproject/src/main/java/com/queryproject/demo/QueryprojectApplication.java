package com.queryproject.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueryprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueryprojectApplication.class, args);
	}

}
