package com.queryproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.queryproject.demo.model.Student;
import com.queryproject.demo.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	StudentService studService;
	@GetMapping("/fetchByDept")
	public List<Student> fetchStudentByDept(@RequestParam String dept)
	{
		return studService.getStudentsByDept(dept);
	}
	@DeleteMapping("/deleteStudentByName/{name}")
    public String deleteStudentByName(@PathVariable String name)
    {
 	   int result = studService.deleteStudentByName(name);
 	   if(result>0)
 		     return "Student record deleted";
 	   else
 		     return "Problem occured while deleting";
    }
    @PutMapping("/updateStudentByName/{dept}/{name}")
    public String updateStudentByName(@PathVariable String dept,@PathVariable String name)
    {
 	   int res = studService.updateStudentByName(dept, name);
 	   if(res>0)
 		      return "Student record updated";
 	   else
 		    return "Problem occured";

}
}